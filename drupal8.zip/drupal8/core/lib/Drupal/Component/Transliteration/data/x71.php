<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'hu', 'xi', 'shu', 'he', 'xun', 'ku', 'juan', 'xiao', 'xi', 'yan', 'han', 'zhuang', 'jun', 'di', 'xie', 'ji',
  0x10 => 'wu', 'yan', 'lu', 'han', 'yan', 'huan', 'men', 'ju', 'dao', 'bei', 'fen', 'lin', 'kun', 'hun', 'tun', 'xi',
  0x20 => 'cui', 'wu', 'hong', 'chao', 'fu', 'wo', 'jiao', 'cong', 'feng', 'ping', 'qiong', 'ruo', 'xi', 'qiong', 'xin', 'chao',
  0x30 => 'yan', 'yan', 'yi', 'jue', 'yu', 'gang', 'ran', 'pi', 'xiong', 'wang', 'sheng', 'chang', 'shao', 'xiong', 'nian', 'geng',
  0x40 => 'wei', 'chen', 'he', 'kui', 'zhong', 'duan', 'xia', 'hui', 'feng', 'lian', 'xuan', 'xing', 'huang', 'jiao', 'jian', 'bi',
  0x50 => 'ying', 'zhu', 'wei', 'tuan', 'shan', 'xi', 'nuan', 'nuan', 'chan', 'yan', 'jiong', 'jiong', 'yu', 'mei', 'sha', 'wei',
  0x60 => 'zha', 'xin', 'qiong', 'rou', 'mei', 'huan', 'xu', 'zhao', 'wei', 'fan', 'qiu', 'sui', 'yang', 'lie', 'zhu', 'jie',
  0x70 => 'gao', 'gua', 'bao', 'hu', 'yun', 'xia', 'shi', 'liang', 'bian', 'gou', 'tui', 'tang', 'chao', 'shan', 'en', 'bo',
  0x80 => 'huang', 'xie', 'xi', 'wu', 'xi', 'yun', 'he', 'he', 'xi', 'yun', 'xiong', 'nai', 'shan', 'qiong', 'yao', 'xun',
  0x90 => 'mi', 'lian', 'ying', 'wu', 'rong', 'gong', 'yan', 'qiang', 'liu', 'xi', 'bi', 'biao', 'cong', 'lu', 'jian', 'shu',
  0xA0 => 'yi', 'lou', 'peng', 'sui', 'yi', 'teng', 'jue', 'zong', 'yun', 'hu', 'yi', 'zhi', 'ao', 'wei', 'liu', 'han',
  0xB0 => 'ou', 're', 'jiong', 'man', 'kun', 'shang', 'cuan', 'zeng', 'jian', 'xi', 'xi', 'xi', 'yi', 'xiao', 'chi', 'huang',
  0xC0 => 'chan', 'ye', 'tan', 'ran', 'yan', 'xian', 'qiao', 'jun', 'deng', 'dun', 'shen', 'jiao', 'fen', 'si', 'liao', 'yu',
  0xD0 => 'lin', 'tong', 'shao', 'fen', 'fan', 'yan', 'xun', 'lan', 'mei', 'tang', 'yi', 'jing', 'men', 'jing', 'jiao', 'ying',
  0xE0 => 'yu', 'yi', 'xue', 'lan', 'tai', 'zao', 'can', 'sui', 'xi', 'que', 'cong', 'lian', 'hui', 'zhu', 'xie', 'ling',
  0xF0 => 'wei', 'yi', 'xie', 'zhao', 'hui', 'da', 'nong', 'lan', 'ru', 'xian', 'kao', 'xun', 'jin', 'chou', 'dao', 'yao',
];
